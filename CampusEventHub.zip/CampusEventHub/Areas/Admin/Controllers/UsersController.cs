using CampusEventHub.Models;
using CampusEventHub.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusEventHub.Areas.Admin.Controllers;

[Area("Admin")]
[Authorize(Roles = AppRoles.Admin)]
public class UsersController : Controller
{
    private readonly UserManager<ApplicationUser> _users;

    public UsersController(UserManager<ApplicationUser> users)
    {
        _users = users;
    }

    public async Task<IActionResult> Index()
    {
        var all = await _users.Users.AsNoTracking().OrderBy(u => u.FullName).ToListAsync();
        var rows = new List<UserRowVM>();

        foreach (var u in all)
        {
            var roles = await _users.GetRolesAsync(u);
            rows.Add(new UserRowVM
            {
                Id = u.Id,
                FullName = u.FullName,
                Email = u.Email ?? string.Empty,
                EnrollmentNo = u.EnrollmentNo,
                Role = roles.FirstOrDefault() ?? AppRoles.Student
            });
        }

        return View(rows);
    }

    [HttpPost]
    public async Task<IActionResult> SetRole(string id, string role)
    {
        if (!AppRoles.All.Contains(role)) return BadRequest();

        var user = await _users.FindByIdAsync(id);
        if (user == null) return NotFound();

        if (user.Id == _users.GetUserId(User))
        {
            TempData["Error"] = "You cannot change your own role.";
            return RedirectToAction(nameof(Index));
        }

        var current = await _users.GetRolesAsync(user);
        await _users.RemoveFromRolesAsync(user, current);
        await _users.AddToRoleAsync(user, role);

        TempData["Success"] = $"{user.FullName} is now {role}.";
        return RedirectToAction(nameof(Index));
    }
}
