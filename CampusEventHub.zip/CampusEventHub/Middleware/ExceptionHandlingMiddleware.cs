using Microsoft.AspNetCore.Mvc;

namespace CampusEventHub.Middleware;

/// <summary>
/// Central place to log unhandled exceptions. API calls get an RFC 7807 problem
/// response, MVC pages are redirected to the friendly error page.
/// </summary>
public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;
    private readonly IHostEnvironment _env;

    public ExceptionHandlingMiddleware(
        RequestDelegate next,
        ILogger<ExceptionHandlingMiddleware> logger,
        IHostEnvironment env)
    {
        _next = next;
        _logger = logger;
        _env = env;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled exception for {Method} {Path}",
                context.Request.Method, context.Request.Path);

            if (context.Response.HasStarted)
            {
                throw;
            }

            var isApi = context.Request.Path.StartsWithSegments("/api");

            // In development let the developer exception page show MVC errors
            if (_env.IsDevelopment() && !isApi)
            {
                throw;
            }

            context.Response.Clear();

            if (isApi)
            {
                context.Response.StatusCode = StatusCodes.Status500InternalServerError;
                await context.Response.WriteAsJsonAsync(new ProblemDetails
                {
                    Status = StatusCodes.Status500InternalServerError,
                    Title = "An unexpected error occurred.",
                    Instance = context.Request.Path
                });
            }
            else
            {
                context.Response.Redirect("/Home/Error");
            }
        }
    }
}
