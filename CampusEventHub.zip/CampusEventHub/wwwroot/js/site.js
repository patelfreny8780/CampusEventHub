// Auto-dismiss success/error banners after 6 seconds
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".alert-dismissible").forEach(function (el) {
        setTimeout(function () {
            if (window.bootstrap) {
                bootstrap.Alert.getOrCreateInstance(el).close();
            }
        }, 6000);
    });
});
