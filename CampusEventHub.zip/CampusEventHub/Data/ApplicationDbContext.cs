using CampusEventHub.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CampusEventHub.Data;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<Event> Events => Set<Event>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Venue> Venues => Set<Venue>();
    public DbSet<Registration> Registrations => Set<Registration>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<Event>(e =>
        {
            e.HasQueryFilter(x => !x.IsDeleted);
            e.Property(x => x.Title).HasMaxLength(150).IsRequired();
            e.HasIndex(x => x.StartTime);

            e.HasOne(x => x.Category)
                .WithMany(c => c.Events)
                .HasForeignKey(x => x.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);

            e.HasOne(x => x.Venue)
                .WithMany(v => v.Events)
                .HasForeignKey(x => x.VenueId)
                .OnDelete(DeleteBehavior.Restrict);

            e.HasOne(x => x.Organizer)
                .WithMany()
                .HasForeignKey(x => x.OrganizerId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<Registration>(r =>
        {
            // Keep registrations hidden together with their soft-deleted event
            r.HasQueryFilter(x => !x.Event.IsDeleted);

            // One row per (event, user). Cancelled rows are re-activated on re-register.
            r.HasIndex(x => new { x.EventId, x.UserId }).IsUnique();

            r.HasOne(x => x.Event)
                .WithMany(e => e.Registrations)
                .HasForeignKey(x => x.EventId)
                .OnDelete(DeleteBehavior.Cascade);

            r.HasOne(x => x.User)
                .WithMany(u => u.Registrations)
                .HasForeignKey(x => x.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        builder.Entity<Category>().HasIndex(c => c.Name).IsUnique();
    }
}
