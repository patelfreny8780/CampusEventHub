using CampusEventHub.Models;
using CampusEventHub.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace CampusEventHub.Data;

/// <summary>Creates the database and fills it with demo data on first run.</summary>
public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        var db = services.GetRequiredService<ApplicationDbContext>();
        var roles = services.GetRequiredService<RoleManager<IdentityRole>>();
        var users = services.GetRequiredService<UserManager<ApplicationUser>>();

        await db.Database.EnsureCreatedAsync();

        foreach (var role in AppRoles.All)
        {
            if (!await roles.RoleExistsAsync(role))
            {
                await roles.CreateAsync(new IdentityRole(role));
            }
        }

        await EnsureUserAsync(users, "admin@campus.local", "System Admin", null, "Admin@123", AppRoles.Admin);
        var organizer = await EnsureUserAsync(users, "organizer@campus.local", "Riya Organizer", null, "Organizer@123", AppRoles.Organizer);

        var students = new List<ApplicationUser>();
        for (var i = 1; i <= 6; i++)
        {
            students.Add(await EnsureUserAsync(
                users,
                $"student{i}@campus.local",
                $"Demo Student {i}",
                $"2025031000{i:D5}",
                "Student@123",
                AppRoles.Student));
        }

        if (await db.Events.IgnoreQueryFilters().AnyAsync()) return;

        var categories = new[]
        {
            new Category { Name = "Technical", ColorHex = "#2563eb" },
            new Category { Name = "Cultural",  ColorHex = "#db2777" },
            new Category { Name = "Sports",    ColorHex = "#16a34a" },
            new Category { Name = "Workshop",  ColorHex = "#ea580c" },
            new Category { Name = "Seminar",   ColorHex = "#7c3aed" }
        };
        db.Categories.AddRange(categories);

        var venues = new[]
        {
            new Venue { Name = "Main Auditorium", Location = "Block A, Ground Floor", Capacity = 500 },
            new Venue { Name = "Seminar Hall",    Location = "Block B, 2nd Floor",    Capacity = 150 },
            new Venue { Name = "Computer Lab 3",  Location = "IT Building, 1st Floor", Capacity = 60 },
            new Venue { Name = "Sports Ground",   Location = "Campus East Gate",       Capacity = 1000 }
        };
        db.Venues.AddRange(venues);
        await db.SaveChangesAsync();

        var today = DateTime.Today;
        var events = new[]
        {
            NewEvent("CodeSprint Hackathon", "A 24-hour team hackathon. Build, pitch and win prizes with mentors from the industry.",
                today.AddDays(5).AddHours(9), today.AddDays(6).AddHours(9), 3, 200, categories[0], venues[2], organizer),
            NewEvent("Cloud & DevOps Workshop", "Hands-on workshop on containers, CI/CD pipelines and deploying ASP.NET Core apps.",
                today.AddDays(9).AddHours(10), today.AddDays(9).AddHours(16), 60, 150, categories[3], venues[2], organizer),
            NewEvent("Annual Cultural Night", "Music, dance and drama performances by student clubs. Open to everyone.",
                today.AddDays(14).AddHours(18), today.AddDays(14).AddHours(22), 500, 0, categories[1], venues[0], organizer),
            NewEvent("Inter-College Cricket Cup", "Knock-out cricket tournament with eight college teams.",
                today.AddDays(20).AddHours(8), today.AddDays(21).AddHours(17), 200, 50, categories[2], venues[3], organizer),
            NewEvent("AI in Healthcare Seminar", "Guest lecture on practical machine learning applications in modern healthcare.",
                today.AddDays(3).AddHours(11), today.AddDays(3).AddHours(13), 150, 0, categories[4], venues[1], organizer),
            NewEvent("Resume & Interview Masterclass", "Placement-cell session on resumes, aptitude tests and mock interviews.",
                today.AddDays(11).AddHours(14), today.AddDays(11).AddHours(17), 4, 0, categories[3], venues[1], organizer),
            NewEvent("Web Dev Bootcamp (Completed)", "A past event kept to show how finished events appear in reports.",
                today.AddDays(-12).AddHours(10), today.AddDays(-12).AddHours(15), 60, 100, categories[0], venues[2], organizer)
        };
        db.Events.AddRange(events);
        await db.SaveChangesAsync();

        // Demo registrations (event index, how many students). Small capacities demo the waitlist.
        var plan = new (int EventIdx, int Students)[] { (0, 5), (1, 6), (2, 4), (3, 3), (4, 6), (5, 6), (6, 4) };
        var rnd = new Random(42);

        foreach (var (idx, count) in plan)
        {
            var ev = events[idx];
            for (var s = 0; s < count; s++)
            {
                var confirmedSoFar = s; // students register one after another
                db.Registrations.Add(new Registration
                {
                    EventId = ev.Id,
                    UserId = students[s].Id,
                    Status = confirmedSoFar < ev.Capacity ? RegistrationStatus.Confirmed : RegistrationStatus.Waitlisted,
                    RegisteredAt = DateTime.Now.AddDays(-rnd.Next(0, 7)).AddMinutes(-rnd.Next(0, 600)),
                    TicketCode = RegistrationService.NewTicketCode()
                });
            }
        }

        await db.SaveChangesAsync();
    }

    private static Event NewEvent(string title, string description, DateTime start, DateTime end,
        int capacity, decimal price, Category category, Venue venue, ApplicationUser organizer) => new()
    {
        Title = title,
        Description = description,
        StartTime = start,
        EndTime = end,
        Capacity = capacity,
        Price = price,
        CategoryId = category.Id,
        VenueId = venue.Id,
        OrganizerId = organizer.Id,
        IsPublished = true
    };

    private static async Task<ApplicationUser> EnsureUserAsync(
        UserManager<ApplicationUser> users, string email, string fullName,
        string? enrollmentNo, string password, string role)
    {
        var existing = await users.FindByEmailAsync(email);
        if (existing != null) return existing;

        var user = new ApplicationUser
        {
            UserName = email,
            Email = email,
            EmailConfirmed = true,
            FullName = fullName,
            EnrollmentNo = enrollmentNo
        };

        var result = await users.CreateAsync(user, password);
        if (!result.Succeeded)
        {
            throw new InvalidOperationException(
                "Seeding user failed: " + string.Join("; ", result.Errors.Select(e => e.Description)));
        }

        await users.AddToRoleAsync(user, role);
        return user;
    }
}
