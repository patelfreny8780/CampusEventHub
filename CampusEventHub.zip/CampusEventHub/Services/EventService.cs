using CampusEventHub.Models;
using CampusEventHub.Repositories;
using CampusEventHub.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace CampusEventHub.Services;

public record EventFilter(string? Query, int? CategoryId, bool UpcomingOnly, int Page, int PageSize);

public interface IEventService
{
    Task<PagedResult<EventCardVM>> SearchAsync(EventFilter filter);
    Task<Event?> GetAsync(int id);
    Task<EventDetailsVM?> GetDetailsAsync(int id, string? userId, bool isAdmin);
    Task<int> CreateAsync(EventFormVM vm, string organizerId);
    Task<(bool Ok, string? Error)> UpdateAsync(EventFormVM vm);
    Task<bool> DeleteAsync(int id);
    Task<List<SelectListItem>> CategoryItemsAsync();
    Task<List<SelectListItem>> VenueItemsAsync();
}

public class EventService : IEventService
{
    private static readonly string[] AllowedExtensions = { ".jpg", ".jpeg", ".png", ".webp" };
    private const long MaxBannerBytes = 2 * 1024 * 1024;
    private const string BannerUrlPrefix = "/uploads/events/";

    private readonly IUnitOfWork _uow;
    private readonly IWebHostEnvironment _env;
    private readonly ILogger<EventService> _logger;

    public EventService(IUnitOfWork uow, IWebHostEnvironment env, ILogger<EventService> logger)
    {
        _uow = uow;
        _env = env;
        _logger = logger;
    }

    public async Task<PagedResult<EventCardVM>> SearchAsync(EventFilter f)
    {
        var page = Math.Max(1, f.Page);
        var pageSize = Math.Clamp(f.PageSize, 1, 50);

        var query = _uow.Events.Query().AsNoTracking().Where(e => e.IsPublished);

        if (!string.IsNullOrWhiteSpace(f.Query))
        {
            var pattern = $"%{f.Query.Trim()}%";
            query = query.Where(e =>
                EF.Functions.Like(e.Title, pattern) ||
                EF.Functions.Like(e.Description, pattern));
        }

        if (f.CategoryId.HasValue)
        {
            query = query.Where(e => e.CategoryId == f.CategoryId.Value);
        }

        if (f.UpcomingOnly)
        {
            var now = DateTime.Now;
            query = query.Where(e => e.EndTime >= now);
        }

        var total = await query.CountAsync();

        var items = await query
            .OrderBy(e => e.StartTime)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(e => new EventCardVM
            {
                Id = e.Id,
                Title = e.Title,
                StartTime = e.StartTime,
                EndTime = e.EndTime,
                CategoryName = e.Category.Name,
                CategoryColor = e.Category.ColorHex,
                VenueName = e.Venue.Name,
                BannerPath = e.BannerPath,
                Price = e.Price,
                Capacity = e.Capacity,
                ConfirmedCount = e.Registrations.Count(r => r.Status == RegistrationStatus.Confirmed)
            })
            .ToListAsync();

        return new PagedResult<EventCardVM>(items, page, pageSize, total);
    }

    public Task<Event?> GetAsync(int id) =>
        _uow.Events.Query()
            .AsNoTracking()
            .Include(e => e.Category)
            .Include(e => e.Venue)
            .Include(e => e.Organizer)
            .FirstOrDefaultAsync(e => e.Id == id);

    public async Task<EventDetailsVM?> GetDetailsAsync(int id, string? userId, bool isAdmin)
    {
        var ev = await GetAsync(id);
        if (ev == null) return null;

        var active = await _uow.Registrations.Query()
            .AsNoTracking()
            .Include(r => r.User)
            .Where(r => r.EventId == id && r.Status != RegistrationStatus.Cancelled)
            .OrderBy(r => r.RegisteredAt)
            .ToListAsync();

        var canManage = isAdmin || (userId != null && ev.OrganizerId == userId);

        return new EventDetailsVM
        {
            Event = ev,
            ConfirmedCount = active.Count(r => r.Status == RegistrationStatus.Confirmed),
            WaitlistCount = active.Count(r => r.Status == RegistrationStatus.Waitlisted),
            MyRegistration = userId == null ? null : active.FirstOrDefault(r => r.UserId == userId),
            CanManage = canManage,
            Attendees = canManage ? active : new List<Registration>()
        };
    }

    public async Task<int> CreateAsync(EventFormVM vm, string organizerId)
    {
        var ev = new Event { OrganizerId = organizerId, CreatedAt = DateTime.Now };
        Apply(ev, vm);
        ev.BannerPath = await SaveBannerAsync(vm.Banner);

        await _uow.Events.AddAsync(ev);
        await _uow.SaveChangesAsync();

        _logger.LogInformation("Event {EventId} '{Title}' created by {User}", ev.Id, ev.Title, organizerId);
        return ev.Id;
    }

    public async Task<(bool Ok, string? Error)> UpdateAsync(EventFormVM vm)
    {
        var ev = await _uow.Events.Query().FirstOrDefaultAsync(e => e.Id == vm.Id);
        if (ev == null) return (false, "Event not found.");

        var confirmed = await _uow.Registrations.Query()
            .CountAsync(r => r.EventId == ev.Id && r.Status == RegistrationStatus.Confirmed);

        if (vm.Capacity < confirmed)
        {
            return (false, $"Capacity cannot be lower than the {confirmed} confirmed registrations.");
        }

        Apply(ev, vm);

        if (vm.Banner is { Length: > 0 })
        {
            DeleteBanner(ev.BannerPath);
            ev.BannerPath = await SaveBannerAsync(vm.Banner);
        }

        // If capacity increased, promote people from the waitlist (first come, first served)
        var free = ev.Capacity - confirmed;
        if (free > 0)
        {
            var waiting = await _uow.Registrations.Query()
                .Where(r => r.EventId == ev.Id && r.Status == RegistrationStatus.Waitlisted)
                .OrderBy(r => r.RegisteredAt)
                .Take(free)
                .ToListAsync();

            foreach (var w in waiting)
            {
                w.Status = RegistrationStatus.Confirmed;
            }
        }

        await _uow.SaveChangesAsync();
        return (true, null);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var ev = await _uow.Events.Query().FirstOrDefaultAsync(e => e.Id == id);
        if (ev == null) return false;

        ev.IsDeleted = true; // soft delete
        await _uow.SaveChangesAsync();
        _logger.LogInformation("Event {EventId} soft-deleted", id);
        return true;
    }

    public async Task<List<SelectListItem>> CategoryItemsAsync()
    {
        var rows = await _uow.Categories.Query().AsNoTracking()
            .OrderBy(c => c.Name)
            .Select(c => new { c.Id, c.Name })
            .ToListAsync();

        return rows.Select(c => new SelectListItem(c.Name, c.Id.ToString())).ToList();
    }

    public async Task<List<SelectListItem>> VenueItemsAsync()
    {
        var rows = await _uow.Venues.Query().AsNoTracking()
            .OrderBy(v => v.Name)
            .Select(v => new { v.Id, v.Name, v.Capacity })
            .ToListAsync();

        return rows.Select(v => new SelectListItem($"{v.Name} (seats {v.Capacity})", v.Id.ToString())).ToList();
    }

    /// <summary>Returns an error message, or null when the file is acceptable.</summary>
    public static string? ValidateBanner(IFormFile? file)
    {
        if (file == null || file.Length == 0) return null;

        if (file.Length > MaxBannerBytes) return "Banner image must be 2 MB or smaller.";

        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (!AllowedExtensions.Contains(ext)) return "Only .jpg, .jpeg, .png and .webp images are allowed.";

        return null;
    }

    private static void Apply(Event ev, EventFormVM vm)
    {
        ev.Title = vm.Title.Trim();
        ev.Description = vm.Description.Trim();
        ev.StartTime = vm.StartTime;
        ev.EndTime = vm.EndTime;
        ev.Capacity = vm.Capacity;
        ev.Price = vm.Price;
        ev.CategoryId = vm.CategoryId;
        ev.VenueId = vm.VenueId;
        ev.IsPublished = vm.IsPublished;
    }

    private async Task<string?> SaveBannerAsync(IFormFile? file)
    {
        if (file == null || file.Length == 0) return null;

        if (ValidateBanner(file) is { } error)
        {
            throw new InvalidOperationException(error);
        }

        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        var folder = Path.Combine(_env.WebRootPath, "uploads", "events");
        Directory.CreateDirectory(folder);

        var fileName = $"{Guid.NewGuid():N}{ext}"; // never trust the client file name
        await using (var stream = File.Create(Path.Combine(folder, fileName)))
        {
            await file.CopyToAsync(stream);
        }

        return BannerUrlPrefix + fileName;
    }

    private void DeleteBanner(string? bannerPath)
    {
        if (string.IsNullOrEmpty(bannerPath) || !bannerPath.StartsWith(BannerUrlPrefix)) return;

        var fileName = Path.GetFileName(bannerPath);
        var full = Path.Combine(_env.WebRootPath, "uploads", "events", fileName);
        if (File.Exists(full))
        {
            File.Delete(full);
        }
    }
}
