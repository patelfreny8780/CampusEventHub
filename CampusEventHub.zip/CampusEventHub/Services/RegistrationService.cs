using CampusEventHub.Models;
using CampusEventHub.Repositories;
using Microsoft.EntityFrameworkCore;

namespace CampusEventHub.Services;

public record RegistrationResult(bool Success, string Message, RegistrationStatus? Status = null);

public interface IRegistrationService
{
    Task<RegistrationResult> RegisterAsync(int eventId, string userId);
    Task<RegistrationResult> CancelAsync(int registrationId, string userId, bool isAdmin);
    Task<List<Registration>> GetForUserAsync(string userId);
}

public class RegistrationService : IRegistrationService
{
    private readonly IUnitOfWork _uow;
    private readonly ILogger<RegistrationService> _logger;

    public RegistrationService(IUnitOfWork uow, ILogger<RegistrationService> logger)
    {
        _uow = uow;
        _logger = logger;
    }

    public static string NewTicketCode() => Guid.NewGuid().ToString("N")[..10].ToUpperInvariant();

    public async Task<RegistrationResult> RegisterAsync(int eventId, string userId)
    {
        var ev = await _uow.Events.Query()
            .AsNoTracking()
            .FirstOrDefaultAsync(e => e.Id == eventId && e.IsPublished);

        if (ev == null) return new(false, "Event not found.");
        if (ev.EndTime < DateTime.Now) return new(false, "This event has already ended.");

        var existing = await _uow.Registrations.Query()
            .FirstOrDefaultAsync(r => r.EventId == eventId && r.UserId == userId);

        if (existing != null && existing.Status != RegistrationStatus.Cancelled)
        {
            return new(false, "You are already registered for this event.", existing.Status);
        }

        var confirmed = await _uow.Registrations.Query()
            .CountAsync(r => r.EventId == eventId && r.Status == RegistrationStatus.Confirmed);

        var status = confirmed < ev.Capacity
            ? RegistrationStatus.Confirmed
            : RegistrationStatus.Waitlisted;

        if (existing == null)
        {
            await _uow.Registrations.AddAsync(new Registration
            {
                EventId = eventId,
                UserId = userId,
                Status = status,
                RegisteredAt = DateTime.Now,
                TicketCode = NewTicketCode()
            });
        }
        else
        {
            // Re-activate a previously cancelled registration
            existing.Status = status;
            existing.RegisteredAt = DateTime.Now;
            existing.TicketCode = NewTicketCode();
        }

        try
        {
            await _uow.SaveChangesAsync();
        }
        catch (DbUpdateException ex)
        {
            // Unique (EventId, UserId) index hit by a double-click / parallel request
            _logger.LogWarning(ex, "Duplicate registration attempt for event {EventId}", eventId);
            return new(false, "You are already registered for this event.");
        }

        if (status == RegistrationStatus.Confirmed)
        {
            return new RegistrationResult(true, "You're in! Your seat is confirmed.", status);
        }

        return new RegistrationResult(true, "The event is full, so you were added to the waitlist.", status);
    }

    public async Task<RegistrationResult> CancelAsync(int registrationId, string userId, bool isAdmin)
    {
        var reg = await _uow.Registrations.Query().FirstOrDefaultAsync(r => r.Id == registrationId);

        if (reg == null) return new(false, "Registration not found.");
        if (reg.UserId != userId && !isAdmin) return new(false, "You can only cancel your own registration.");
        if (reg.Status == RegistrationStatus.Cancelled) return new(false, "This registration is already cancelled.");

        var wasConfirmed = reg.Status == RegistrationStatus.Confirmed;
        reg.Status = RegistrationStatus.Cancelled;

        // A freed seat goes to the longest-waiting person
        if (wasConfirmed)
        {
            var next = await _uow.Registrations.Query()
                .Where(r => r.EventId == reg.EventId && r.Status == RegistrationStatus.Waitlisted)
                .OrderBy(r => r.RegisteredAt)
                .FirstOrDefaultAsync();

            if (next != null)
            {
                next.Status = RegistrationStatus.Confirmed;
                _logger.LogInformation("Waitlisted registration {Id} promoted to confirmed", next.Id);
            }
        }

        await _uow.SaveChangesAsync();
        return new(true, "Registration cancelled.", RegistrationStatus.Cancelled);
    }

    public Task<List<Registration>> GetForUserAsync(string userId) =>
        _uow.Registrations.Query()
            .AsNoTracking()
            .Include(r => r.Event).ThenInclude(e => e.Venue)
            .Include(r => r.Event).ThenInclude(e => e.Category)
            .Where(r => r.UserId == userId)
            .OrderByDescending(r => r.Event.StartTime)
            .ToListAsync();
}
