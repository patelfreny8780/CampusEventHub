using CampusEventHub.Data;
using CampusEventHub.Models;
using CampusEventHub.ViewModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace CampusEventHub.Services;

public interface IDashboardService
{
    Task<DashboardVM> GetAsync();
}

/// <summary>
/// Read-only reporting queries. Uses the DbContext directly because these
/// aggregate across several tables; the result is cached for one minute.
/// </summary>
public class DashboardService : IDashboardService
{
    private const string CacheKey = "admin-dashboard";

    private readonly ApplicationDbContext _db;
    private readonly IMemoryCache _cache;

    public DashboardService(ApplicationDbContext db, IMemoryCache cache)
    {
        _db = db;
        _cache = cache;
    }

    public async Task<DashboardVM> GetAsync()
    {
        var vm = await _cache.GetOrCreateAsync(CacheKey, async entry =>
        {
            entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(60);
            return await BuildAsync();
        });

        return vm!;
    }

    private async Task<DashboardVM> BuildAsync()
    {
        var now = DateTime.Now;
        var vm = new DashboardVM { GeneratedAt = now };

        vm.TotalEvents = await _db.Events.CountAsync();
        vm.UpcomingEvents = await _db.Events.CountAsync(e => e.IsPublished && e.StartTime >= now);
        vm.TotalUsers = await _db.Users.CountAsync();
        vm.ConfirmedRegistrations = await _db.Registrations.CountAsync(r => r.Status == RegistrationStatus.Confirmed);
        vm.WaitlistedRegistrations = await _db.Registrations.CountAsync(r => r.Status == RegistrationStatus.Waitlisted);

        // Per-event numbers. Money maths is done in memory because SQLite
        // cannot aggregate decimal columns.
        var perEvent = await _db.Events
            .Select(e => new
            {
                e.Title,
                e.Price,
                e.Capacity,
                Confirmed = e.Registrations.Count(r => r.Status == RegistrationStatus.Confirmed)
            })
            .ToListAsync();

        vm.EstimatedRevenue = perEvent.Sum(x => x.Price * x.Confirmed);

        vm.TopEvents = perEvent
            .OrderByDescending(x => x.Confirmed)
            .Take(5)
            .Select(x => new TopEventRow { Title = x.Title, Confirmed = x.Confirmed, Capacity = x.Capacity })
            .ToList();

        var byCategory = await _db.Registrations
            .Where(r => r.Status == RegistrationStatus.Confirmed)
            .GroupBy(r => r.Event.Category.Name)
            .Select(g => new { Label = g.Key, Count = g.Count() })
            .ToListAsync();

        vm.RegistrationsByCategory = byCategory
            .OrderByDescending(x => x.Count)
            .Select(x => new ChartPoint { Label = x.Label, Value = x.Count })
            .ToList();

        var since = DateTime.Today.AddDays(-6);
        var dates = await _db.Registrations
            .Where(r => r.RegisteredAt >= since)
            .Select(r => r.RegisteredAt)
            .ToListAsync();

        vm.RegistrationsLast7Days = Enumerable.Range(0, 7)
            .Select(i => since.AddDays(i))
            .Select(day => new ChartPoint
            {
                Label = day.ToString("dd MMM"),
                Value = dates.Count(d => d.Date == day.Date)
            })
            .ToList();

        return vm;
    }
}
