using CampusEventHub.Data;
using CampusEventHub.Models;
using Microsoft.EntityFrameworkCore;

namespace CampusEventHub.Repositories;

public interface IRepository<T> where T : class
{
    IQueryable<T> Query();
    Task AddAsync(T entity);
    void Update(T entity);
    void Remove(T entity);
}

public class Repository<T> : IRepository<T> where T : class
{
    private readonly DbSet<T> _set;

    public Repository(ApplicationDbContext db)
    {
        _set = db.Set<T>();
    }

    public IQueryable<T> Query() => _set.AsQueryable();

    public async Task AddAsync(T entity) => await _set.AddAsync(entity);

    public void Update(T entity) => _set.Update(entity);

    public void Remove(T entity) => _set.Remove(entity);
}

public interface IUnitOfWork
{
    IRepository<Event> Events { get; }
    IRepository<Category> Categories { get; }
    IRepository<Venue> Venues { get; }
    IRepository<Registration> Registrations { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}

public class UnitOfWork : IUnitOfWork
{
    private readonly ApplicationDbContext _db;

    public UnitOfWork(ApplicationDbContext db)
    {
        _db = db;
        Events = new Repository<Event>(db);
        Categories = new Repository<Category>(db);
        Venues = new Repository<Venue>(db);
        Registrations = new Repository<Registration>(db);
    }

    public IRepository<Event> Events { get; }
    public IRepository<Category> Categories { get; }
    public IRepository<Venue> Venues { get; }
    public IRepository<Registration> Registrations { get; }

    public Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        => _db.SaveChangesAsync(cancellationToken);
}
