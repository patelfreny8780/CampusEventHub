namespace CampusEventHub.Models;

public static class AppRoles
{
    public const string Admin = "Admin";
    public const string Organizer = "Organizer";
    public const string Student = "Student";

    public const string AdminOrOrganizer = Admin + "," + Organizer;

    public static readonly string[] All = { Admin, Organizer, Student };
}
