using System.ComponentModel.DataAnnotations;

namespace CampusEventHub.Models;

public enum RegistrationStatus
{
    Confirmed = 1,
    Waitlisted = 2,
    Cancelled = 3
}

public class Category
{
    public int Id { get; set; }

    [Required, StringLength(60)]
    public string Name { get; set; } = string.Empty;

    [StringLength(7)]
    public string ColorHex { get; set; } = "#0d6efd";

    public ICollection<Event> Events { get; set; } = new List<Event>();
}

public class Venue
{
    public int Id { get; set; }

    [Required, StringLength(100)]
    public string Name { get; set; } = string.Empty;

    [StringLength(200)]
    public string Location { get; set; } = string.Empty;

    public int Capacity { get; set; }

    public ICollection<Event> Events { get; set; } = new List<Event>();
}

public class Event
{
    public int Id { get; set; }

    [Required, StringLength(150)]
    public string Title { get; set; } = string.Empty;

    [Required, StringLength(4000)]
    public string Description { get; set; } = string.Empty;

    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }

    public int Capacity { get; set; }
    public decimal Price { get; set; }

    public string? BannerPath { get; set; }

    public bool IsPublished { get; set; } = true;

    /// <summary>Soft-delete flag. A global query filter hides deleted events.</summary>
    public bool IsDeleted { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public int CategoryId { get; set; }
    public Category Category { get; set; } = null!;

    public int VenueId { get; set; }
    public Venue Venue { get; set; } = null!;

    public string OrganizerId { get; set; } = string.Empty;
    public ApplicationUser Organizer { get; set; } = null!;

    public ICollection<Registration> Registrations { get; set; } = new List<Registration>();
}

public class Registration
{
    public int Id { get; set; }

    public int EventId { get; set; }
    public Event Event { get; set; } = null!;

    public string UserId { get; set; } = string.Empty;
    public ApplicationUser User { get; set; } = null!;

    public DateTime RegisteredAt { get; set; } = DateTime.Now;
    public RegistrationStatus Status { get; set; }

    [StringLength(20)]
    public string TicketCode { get; set; } = string.Empty;
}
