using CampusEventHub.Models;
using CampusEventHub.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace CampusEventHub.Controllers;

public class AccountController : Controller
{
    private readonly UserManager<ApplicationUser> _users;
    private readonly SignInManager<ApplicationUser> _signIn;
    private readonly ILogger<AccountController> _logger;

    public AccountController(
        UserManager<ApplicationUser> users,
        SignInManager<ApplicationUser> signIn,
        ILogger<AccountController> logger)
    {
        _users = users;
        _signIn = signIn;
        _logger = logger;
    }

    [HttpGet, AllowAnonymous]
    public IActionResult Login(string? returnUrl = null)
    {
        return View(new LoginVM { ReturnUrl = returnUrl });
    }

    [HttpPost, AllowAnonymous]
    public async Task<IActionResult> Login(LoginVM vm)
    {
        if (!ModelState.IsValid) return View(vm);

        var user = await _users.FindByEmailAsync(vm.Email);
        if (user != null)
        {
            var result = await _signIn.PasswordSignInAsync(user, vm.Password, vm.RememberMe, lockoutOnFailure: true);

            if (result.Succeeded)
            {
                _logger.LogInformation("User {Email} signed in", vm.Email);
                return !string.IsNullOrEmpty(vm.ReturnUrl) && Url.IsLocalUrl(vm.ReturnUrl)
                    ? LocalRedirect(vm.ReturnUrl)
                    : RedirectToAction("Index", "Home");
            }

            if (result.IsLockedOut)
            {
                ModelState.AddModelError(string.Empty, "Account locked for 10 minutes after too many failed attempts.");
                return View(vm);
            }
        }

        // Same message for unknown e-mail and wrong password (no user enumeration)
        ModelState.AddModelError(string.Empty, "Invalid e-mail or password.");
        return View(vm);
    }

    [HttpGet, AllowAnonymous]
    public IActionResult Register() => View(new RegisterVM());

    [HttpPost, AllowAnonymous]
    public async Task<IActionResult> Register(RegisterVM vm)
    {
        if (!ModelState.IsValid) return View(vm);

        var user = new ApplicationUser
        {
            UserName = vm.Email,
            Email = vm.Email,
            FullName = vm.FullName.Trim(),
            EnrollmentNo = string.IsNullOrWhiteSpace(vm.EnrollmentNo) ? null : vm.EnrollmentNo.Trim(),
            EmailConfirmed = true // demo project: no e-mail sender configured
        };

        var result = await _users.CreateAsync(user, vm.Password);
        if (!result.Succeeded)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
            return View(vm);
        }

        // Everybody starts as a Student; an Admin can promote users to Organizer
        await _users.AddToRoleAsync(user, AppRoles.Student);
        await _signIn.SignInAsync(user, isPersistent: false);

        TempData["Success"] = "Welcome to CampusEventHub!";
        return RedirectToAction("Index", "Home");
    }

    [HttpPost, Authorize]
    public async Task<IActionResult> Logout()
    {
        await _signIn.SignOutAsync();
        return RedirectToAction("Index", "Home");
    }

    [HttpGet, AllowAnonymous]
    public IActionResult AccessDenied() => View();
}
