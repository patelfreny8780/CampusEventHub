using CampusEventHub.Services;
using Microsoft.AspNetCore.Mvc;

namespace CampusEventHub.Controllers;

public class HomeController : Controller
{
    private readonly IEventService _events;

    public HomeController(IEventService events)
    {
        _events = events;
    }

    public async Task<IActionResult> Index()
    {
        var featured = await _events.SearchAsync(new EventFilter(null, null, true, 1, 6));
        return View(featured.Items);
    }

    [HttpGet]
    public IActionResult Error() => View();
}
