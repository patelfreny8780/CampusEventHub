using System.Security.Claims;
using CampusEventHub.Models;
using CampusEventHub.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CampusEventHub.Controllers;

[Authorize]
public class RegistrationsController : Controller
{
    private readonly IRegistrationService _registrations;

    public RegistrationsController(IRegistrationService registrations)
    {
        _registrations = registrations;
    }

    private string CurrentUserId => User.FindFirstValue(ClaimTypes.NameIdentifier)!;

    [HttpGet]
    public async Task<IActionResult> My()
    {
        var list = await _registrations.GetForUserAsync(CurrentUserId);
        return View(list);
    }

    [HttpPost]
    public async Task<IActionResult> Register(int eventId)
    {
        var result = await _registrations.RegisterAsync(eventId, CurrentUserId);
        TempData[result.Success ? "Success" : "Error"] = result.Message;
        return RedirectToAction("Details", "Events", new { id = eventId });
    }

    [HttpPost]
    public async Task<IActionResult> Cancel(int id, string? returnUrl = null)
    {
        var result = await _registrations.CancelAsync(id, CurrentUserId, User.IsInRole(AppRoles.Admin));
        TempData[result.Success ? "Success" : "Error"] = result.Message;

        return !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)
            ? LocalRedirect(returnUrl)
            : RedirectToAction(nameof(My));
    }
}
