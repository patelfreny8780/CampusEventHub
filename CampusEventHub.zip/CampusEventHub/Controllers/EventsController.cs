using System.Security.Claims;
using System.Text;
using CampusEventHub.Models;
using CampusEventHub.Services;
using CampusEventHub.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CampusEventHub.Controllers;

[Authorize(Roles = AppRoles.AdminOrOrganizer)]
public class EventsController : Controller
{
    private readonly IEventService _events;

    public EventsController(IEventService events)
    {
        _events = events;
    }

    private string? CurrentUserId => User.FindFirstValue(ClaimTypes.NameIdentifier);

    private bool CanManage(Event ev) => User.IsInRole(AppRoles.Admin) || ev.OrganizerId == CurrentUserId;

    // ---------- Public pages ----------

    [AllowAnonymous]
    public async Task<IActionResult> Index(string? q, int? categoryId, bool upcoming = true, int page = 1)
    {
        var vm = new EventListVM
        {
            Result = await _events.SearchAsync(new EventFilter(q, categoryId, upcoming, page, 9)),
            Query = q,
            CategoryId = categoryId,
            Upcoming = upcoming,
            Categories = await _events.CategoryItemsAsync()
        };
        return View(vm);
    }

    [AllowAnonymous]
    public async Task<IActionResult> Details(int id)
    {
        var vm = await _events.GetDetailsAsync(id, CurrentUserId, User.IsInRole(AppRoles.Admin));
        if (vm == null) return NotFound();

        // Drafts are only visible to people who can manage the event
        if (!vm.Event.IsPublished && !vm.CanManage) return NotFound();

        return View(vm);
    }

    // ---------- Organizer / Admin pages ----------

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        var start = DateTime.Today.AddDays(7).AddHours(10);
        var vm = new EventFormVM { StartTime = start, EndTime = start.AddHours(2) };
        await FillListsAsync(vm);
        return View(vm);
    }

    [HttpPost]
    public async Task<IActionResult> Create(EventFormVM vm)
    {
        if (EventService.ValidateBanner(vm.Banner) is { } bannerError)
        {
            ModelState.AddModelError(nameof(vm.Banner), bannerError);
        }

        if (!ModelState.IsValid)
        {
            await FillListsAsync(vm);
            return View(vm);
        }

        var id = await _events.CreateAsync(vm, CurrentUserId!);
        TempData["Success"] = "Event created successfully.";
        return RedirectToAction(nameof(Details), new { id });
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var ev = await _events.GetAsync(id);
        if (ev == null) return NotFound();
        if (!CanManage(ev)) return Forbid();

        var vm = EventFormVM.FromEntity(ev);
        await FillListsAsync(vm);
        return View(vm);
    }

    [HttpPost]
    public async Task<IActionResult> Edit(int id, EventFormVM vm)
    {
        if (id != vm.Id) return BadRequest();

        var ev = await _events.GetAsync(id);
        if (ev == null) return NotFound();
        if (!CanManage(ev)) return Forbid();

        if (EventService.ValidateBanner(vm.Banner) is { } bannerError)
        {
            ModelState.AddModelError(nameof(vm.Banner), bannerError);
        }

        if (ModelState.IsValid)
        {
            var (ok, error) = await _events.UpdateAsync(vm);
            if (ok)
            {
                TempData["Success"] = "Event updated.";
                return RedirectToAction(nameof(Details), new { id });
            }

            ModelState.AddModelError(string.Empty, error ?? "Could not update the event.");
        }

        vm.ExistingBanner = ev.BannerPath;
        await FillListsAsync(vm);
        return View(vm);
    }

    [HttpPost]
    public async Task<IActionResult> Delete(int id)
    {
        var ev = await _events.GetAsync(id);
        if (ev == null) return NotFound();
        if (!CanManage(ev)) return Forbid();

        await _events.DeleteAsync(id);
        TempData["Success"] = "Event deleted.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> ExportAttendees(int id)
    {
        var vm = await _events.GetDetailsAsync(id, CurrentUserId, User.IsInRole(AppRoles.Admin));
        if (vm == null) return NotFound();
        if (!vm.CanManage) return Forbid();

        var sb = new StringBuilder();
        sb.AppendLine("Name,Enrollment,Email,Status,Ticket,RegisteredAt");

        foreach (var r in vm.Attendees)
        {
            sb.AppendLine(string.Join(",",
                Csv(r.User.FullName),
                Csv(r.User.EnrollmentNo),
                Csv(r.User.Email),
                Csv(r.Status.ToString()),
                Csv(r.TicketCode),
                Csv(r.RegisteredAt.ToString("yyyy-MM-dd HH:mm"))));
        }

        // BOM so Excel opens the file as UTF-8
        var bytes = Encoding.UTF8.GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
        return File(bytes, "text/csv", $"attendees-event-{id}.csv");
    }

    private async Task FillListsAsync(EventFormVM vm)
    {
        vm.Categories = await _events.CategoryItemsAsync();
        vm.Venues = await _events.VenueItemsAsync();
    }

    /// <summary>Quotes a CSV cell and neutralises spreadsheet formula injection.</summary>
    private static string Csv(string? value)
    {
        value ??= string.Empty;
        if (value.Length > 0 && "=+-@".Contains(value[0]))
        {
            value = "'" + value;
        }
        return "\"" + value.Replace("\"", "\"\"") + "\"";
    }
}
