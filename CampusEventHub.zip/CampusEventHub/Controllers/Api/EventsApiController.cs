using CampusEventHub.Services;
using CampusEventHub.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace CampusEventHub.Controllers.Api;

/// <summary>Public, read-only JSON API (rate limited to 60 requests / minute).</summary>
[ApiController]
[Route("api/events")]
[EnableRateLimiting("api")]
public class EventsApiController : ControllerBase
{
    private readonly IEventService _events;

    public EventsApiController(IEventService events)
    {
        _events = events;
    }

    /// <summary>GET /api/events?q=hack&amp;categoryId=1&amp;page=1&amp;pageSize=10</summary>
    [HttpGet]
    public async Task<ActionResult<PagedResult<EventCardVM>>> List(
        string? q, int? categoryId, int page = 1, int pageSize = 10, bool upcoming = true)
    {
        var result = await _events.SearchAsync(new EventFilter(q, categoryId, upcoming, page, pageSize));
        return Ok(result);
    }

    /// <summary>GET /api/events/5</summary>
    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var e = await _events.GetAsync(id);
        if (e == null || !e.IsPublished) return NotFound();

        return Ok(new
        {
            e.Id,
            e.Title,
            e.Description,
            e.StartTime,
            e.EndTime,
            e.Capacity,
            e.Price,
            Category = e.Category.Name,
            Venue = e.Venue.Name,
            Location = e.Venue.Location
        });
    }
}
