# CampusEventHub

**Advanced ASP.NET Core 8 MVC web application for managing college events** — event publishing, seat-limited registration with automatic waitlists, role-based access and an analytics dashboard.

Developed by **Freny Patel** · Enrollment **202503103520146**

---

## Features

| Area | What it does |
|------|--------------|
| Authentication | ASP.NET Core Identity (cookie auth), registration, login with account lockout, 3 roles: **Admin**, **Organizer**, **Student** |
| Events | Create / edit / soft-delete events, banner upload (type + size validated), draft/publish switch, category & venue |
| Registration | Live seat count, automatic **waitlist**, automatic **promotion** when someone cancels or capacity is raised, unique ticket code |
| Search | Keyword + category + upcoming filter with server-side **paging** |
| Admin dashboard | KPI cards, Chart.js charts (by category, last 7 days), top events, estimated revenue (cached 60 s) |
| User management | Admin can promote a user to Organizer / Admin |
| Export | Attendee list as CSV (with formula-injection protection) |
| REST API | `GET /api/events`, `GET /api/events/{id}` — rate limited to 60 req/min |

## Architecture

```
Controllers / Areas  ──►  Services  ──►  Repositories (Unit of Work)  ──►  EF Core  ──►  SQLite
      │                      │
   Views (Razor)         ViewModels
```

* **MVC** with an **Admin Area**
* **Repository + Unit of Work** pattern over EF Core
* **Service layer** (`IEventService`, `IRegistrationService`, `IDashboardService`) keeps controllers thin
* **ViewModels** + DataAnnotations + `IValidatableObject` for validation
* **Dependency Injection** throughout, **IMemoryCache**, **global exception middleware**, built-in **rate limiter**
* **Global query filters** implement soft delete

## Security

* Anti-forgery token validated globally on all POST requests
* Role-based `[Authorize]` + ownership check (organizers can only edit their own events)
* Open-redirect protection (`Url.IsLocalUrl`) on login / cancel
* Generic login error message (no user enumeration), lockout after 5 failures
* Upload hardening: extension allow-list, 2 MB limit, server-generated file names
* Security headers (`X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`), HSTS in production

## Run it

Requirements: **.NET 8 SDK**

```bash
cd CampusEventHub
dotnet restore
dotnet run
```

Open the HTTPS URL printed in the console. The SQLite database (`campuseventhub.db`) is created and seeded automatically on first start.

### Demo accounts

| Role | E-mail | Password |
|------|--------|----------|
| Admin | admin@campus.local | Admin@123 |
| Organizer | organizer@campus.local | Organizer@123 |
| Student | student1@campus.local … student6@campus.local | Student@123 |

> Change or remove these accounts (and the hint on the login page) before any real deployment.

### API examples

```
GET /api/events?q=hack&categoryId=1&page=1&pageSize=5
GET /api/events/3
```

## Project structure

```
Areas/Admin/        Dashboard + user management (Admin only)
Controllers/        Home, Account, Events, Registrations, Api/
Data/               ApplicationDbContext, DbSeeder
Middleware/         ExceptionHandlingMiddleware
Models/             Entities, roles
Repositories/       IRepository<T>, IUnitOfWork
Services/           Business logic
ViewModels/         Form / list / dashboard models
Views/              Razor views + shared partials
wwwroot/            CSS, JS, uploaded banners
```

## Notes & next steps

* The database is created with `EnsureCreated()` to keep first run simple. For a production project, switch to EF Core **migrations** (`dotnet ef migrations add Initial`).
* To use SQL Server instead of SQLite, replace the `Microsoft.EntityFrameworkCore.Sqlite` package with `Microsoft.EntityFrameworkCore.SqlServer`, call `UseSqlServer(...)` in `Program.cs` and update the connection string.
* Registration capacity checks are not wrapped in a serializable transaction; under very heavy concurrency add a row-version / transaction to avoid rare over-booking.
* Ideas: e-mail confirmations, QR-code tickets, payment gateway, Swagger/OpenAPI, unit tests with xUnit.
