using System.ComponentModel.DataAnnotations;
using CampusEventHub.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CampusEventHub.ViewModels;

public class PagedResult<T>
{
    public PagedResult(IReadOnlyList<T> items, int page, int pageSize, int totalCount)
    {
        Items = items;
        Page = page;
        PageSize = pageSize;
        TotalCount = totalCount;
    }

    public IReadOnlyList<T> Items { get; }
    public int Page { get; }
    public int PageSize { get; }
    public int TotalCount { get; }
    public int TotalPages => PageSize <= 0 ? 1 : (int)Math.Ceiling(TotalCount / (double)PageSize);
    public bool HasPrevious => Page > 1;
    public bool HasNext => Page < TotalPages;
}

public class EventCardVM
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public DateTime StartTime { get; set; }
    public DateTime EndTime { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public string CategoryColor { get; set; } = "#0d6efd";
    public string VenueName { get; set; } = string.Empty;
    public string? BannerPath { get; set; }
    public decimal Price { get; set; }
    public int Capacity { get; set; }
    public int ConfirmedCount { get; set; }

    public int SeatsLeft => Math.Max(0, Capacity - ConfirmedCount);
    public bool IsFull => ConfirmedCount >= Capacity;
}

public class EventListVM
{
    public PagedResult<EventCardVM> Result { get; set; } = null!;
    public string? Query { get; set; }
    public int? CategoryId { get; set; }
    public bool Upcoming { get; set; } = true;
    public List<SelectListItem> Categories { get; set; } = new();
}

public class EventDetailsVM
{
    public Event Event { get; set; } = null!;
    public int ConfirmedCount { get; set; }
    public int WaitlistCount { get; set; }
    public Registration? MyRegistration { get; set; }
    public bool CanManage { get; set; }
    public List<Registration> Attendees { get; set; } = new();
}

public class EventFormVM : IValidatableObject
{
    public int Id { get; set; }

    [Required, StringLength(150)]
    public string Title { get; set; } = string.Empty;

    [Required, StringLength(4000)]
    public string Description { get; set; } = string.Empty;

    [Required]
    [Display(Name = "Start time")]
    public DateTime StartTime { get; set; }

    [Required]
    [Display(Name = "End time")]
    public DateTime EndTime { get; set; }

    [Range(1, 100000)]
    public int Capacity { get; set; } = 100;

    [Range(0, 100000)]
    [Display(Name = "Ticket price (INR, 0 = free)")]
    public decimal Price { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Please select a category.")]
    [Display(Name = "Category")]
    public int CategoryId { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Please select a venue.")]
    [Display(Name = "Venue")]
    public int VenueId { get; set; }

    [Display(Name = "Publish now")]
    public bool IsPublished { get; set; } = true;

    [Display(Name = "Banner image (jpg / png / webp, max 2 MB)")]
    public IFormFile? Banner { get; set; }

    public string? ExistingBanner { get; set; }

    [ValidateNever]
    public List<SelectListItem> Categories { get; set; } = new();

    [ValidateNever]
    public List<SelectListItem> Venues { get; set; } = new();

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (EndTime <= StartTime)
        {
            yield return new ValidationResult(
                "End time must be after the start time.",
                new[] { nameof(EndTime) });
        }
    }

    public static EventFormVM FromEntity(Event e) => new()
    {
        Id = e.Id,
        Title = e.Title,
        Description = e.Description,
        StartTime = e.StartTime,
        EndTime = e.EndTime,
        Capacity = e.Capacity,
        Price = e.Price,
        CategoryId = e.CategoryId,
        VenueId = e.VenueId,
        IsPublished = e.IsPublished,
        ExistingBanner = e.BannerPath
    };
}
