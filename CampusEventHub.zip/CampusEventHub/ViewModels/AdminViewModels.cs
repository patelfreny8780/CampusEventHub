namespace CampusEventHub.ViewModels;

public class ChartPoint
{
    public string Label { get; set; } = string.Empty;
    public int Value { get; set; }
}

public class TopEventRow
{
    public string Title { get; set; } = string.Empty;
    public int Confirmed { get; set; }
    public int Capacity { get; set; }
    public int FillPercent => Capacity <= 0 ? 0 : Math.Min(100, (int)Math.Round(Confirmed * 100.0 / Capacity));
}

public class DashboardVM
{
    public int TotalEvents { get; set; }
    public int UpcomingEvents { get; set; }
    public int TotalUsers { get; set; }
    public int ConfirmedRegistrations { get; set; }
    public int WaitlistedRegistrations { get; set; }
    public decimal EstimatedRevenue { get; set; }
    public List<ChartPoint> RegistrationsByCategory { get; set; } = new();
    public List<ChartPoint> RegistrationsLast7Days { get; set; } = new();
    public List<TopEventRow> TopEvents { get; set; } = new();
    public DateTime GeneratedAt { get; set; } = DateTime.Now;
}

public class UserRowVM
{
    public string Id { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string? EnrollmentNo { get; set; }
    public string Role { get; set; } = string.Empty;
}
